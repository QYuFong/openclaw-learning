# 合同文档示例 - 用于 ContextPilot 验证

## 文件列表

| 文件 | 大小 | 行数 | 描述 |
|------|------|------|------|
| `contract_alpha_cloud.txt` | 24KB | 376 | Alpha Cloud 云服务合同 |
| `contract_beta_ai.txt` | 28KB | 430 | Beta AI 人工智能服务合同 |
| `contract_gamma_security.txt` | 32KB | 464 | Gamma Security 安全服务合同 |
| `contract_delta_data.txt` | 33KB | 470 | Delta Data 数据分析合同 |
| `contract_epsilon_iot.txt` | 35KB | 490 | Epsilon IoT 物联网合同 |

**总计**: 5份合同，约 164KB，2230行

---

## 重复内容分析

### 完全相同的条款（五份合同共用）

以下条款在所有合同中 **完全相同**（逐字节匹配），ContextPilot 应能去重：

| 条款 | 行数 | 描述 |
|------|------|------|
| Art. 1 — Definitions | ~50行 | 标准法律定义术语 |
| Art. 2 — Scope of Services | ~20行 | 服务范围通用条款 |
| Art. 3 — Term | ~15行 | 合同期限条款 |
| Art. 6 — Data Protection | ~15行 | 数据保护条款 |
| Art. 7 — Intellectual Property | ~10行 | 知识产权条款 |
| Art. 8 — Confidentiality | ~15行 | 保密条款 |
| Art. 9 — Warranties | ~15行 | 保证条款 |
| Art. 10 — Service Level Agreement | ~10行 | 服务级别协议 |
| Art. 11 — Indemnification | ~10行 | 赔偿条款 |
| Art. 12 — Limitation of Liability | ~10行 | 责任限制条款 |
| Art. 14 — Dispute Resolution | ~10行 | 争议解决条款 |
| Art. 15 — Force Majeure | ~10行 | 不可抗力条款 |
| Art. 16 — General Terms | ~15行 | 一般条款 |

**预计共享内容**: 约 **150-180行** × 5份合同 = 重复内容占比 **35-40%**

---

### 各合同特有条款（核心差异）

| 合同 | 特有条款 | 内容特点 |
|------|----------|----------|
| **Alpha Cloud** | Art. 4/5/13/17 | 云服务定价、云基础设施、区域覆盖、云技术栈 |
| **Beta AI** | Art. 4/5/13/17/18 | AI定价、GPU计算、模型服务、AI伦理、内容安全 |
| **Gamma Security** | Art. 4/5/13/17/18/19 | 安全定价、SOC服务、威胁检测、数据保护、高级威胁 |
| **Delta Data** | Art. 4/5/13/17/18/19 | 数据仓库定价、BI服务、数据治理、ML Operations、数据市场 |
| **Epsilon IoT** | Art. 4/5/13/17/18/19/20 | IoT定价、设备连接、边缘计算、数字孪生、设备管理 |

---

## 验证 ContextPilot 效果

### 测试场景

#### 场景 A：基础去重测试（3份合同）

```bash
# 第1次请求：缓存预热
openclaw agent --message "阅读 contracts/contract_alpha_cloud.txt 并总结责任条款"

# 第2次请求：触发去重
openclaw agent --message "阅读 contracts/contract_beta_ai.txt 并与 Alpha 比较责任条款差异"

# 第3次请求：更多重复
openclaw agent --message "阅读 contracts/contract_gamma_security.txt，比较三份合同的责任条款并给出建议"
```

**预期效果**: 第2、3次请求应显示 `chars saved` 统计，因为 Art. 1-16 大量重复

#### 场景 B：扩展验证（5份合同）

```bash
# 第4次请求：新合同但有相同模板
openclaw agent --message "阅读 contracts/contract_delta_data.txt，与前三份合同比较通用条款"

# 第5次请求：第五份合同
openclaw agent --message "阅读 contracts/contract_epsilon_iot.txt，总结五份合同的共同条款和各合同特有条款"
```

**预期效果**: 新合同仍有大量模板内容重复，去重比例应保持稳定

#### 场景 C：KV Cache 验证（避免缓存污染）

为了验证去重效果而非 KV Cache 命中：

```bash
# 清空对话历史，新会话测试
openclaw agent --message "同时阅读 contracts/contract_alpha_cloud.txt 和 contracts/contract_beta_ai.txt，找出它们完全相同的条款"

# 预期：一次请求中读取两份合同，ContextPilot 应在同一请求内去重
```

---

### 检查 ContextPilot 效果

查看 OpenClaw gateway 日志：

```
[ContextPilot] Stats: 5 requests, 75,000 chars saved (~18,750 tokens, ~$0.0562)
```

| 指标 | 预期值 |
|------|--------|
| **Token 节省** | 25-35%（模板条款重复） |
| **chars saved** | 每次新增合同约 15,000-20,000 chars |
| **blocks deduped** | 每次请求约 10-15 个块被替换为引用 |

---

## 文件结构说明

每份合同遵循相同模板结构：

```
标题行（不同 - 供应商名称和服务类型）
================================================================================

Art. 1 — Definitions（完全相同）
Art. 2 — Scope of Services（完全相同）
Art. 3 — Term（完全相同）
Art. 4 — Payment Terms（不同 - 各供应商定价模型）
Art. 5 — Customer Obligations（不同 - 各供应商客户要求）
Art. 6 — Data Protection（完全相同）
Art. 7 — Intellectual Property（完全相同）
Art. 8 — Confidentiality（完全相同）
Art. 9 — Warranties（完全相同）
Art. 10 — Service Level Agreement（完全相同）
Art. 11 — Indemnification（完全相同）
Art. 12 — Limitation of Liability（完全相同）
Art. 13 — Compliance（相同框架 + 不同认证列表）
Art. 14 — Dispute Resolution（完全相同）
Art. 15 — Force Majeure（完全相同）
Art. 16 — General Terms（完全相同）
Art. 17 — [供应商特有服务条款]（完全不同）
Art. 18/19/20 — [供应商特有附加条款]（完全不同）

签名部分（不同）
================================================================================
附录 Exhibit A/B/C/D（不同）
================================================================================
```

---

## 设计目的

1. **验证 Dedup 功能**: Art. 1-16 完全相同，触发内容块去重
2. **验证 Reorder 功能**: 相同模板结构允许前缀对齐优化
3. **避免 KV Cache 干扰**: 新增两份合同 (Delta/Epsilon) 作为新测试数据
4. **测试增量效果**: 从3份扩展到5份，观察去重效果是否稳定
5. **测试跨请求去重**: 多轮对话中跨请求的内容重复处理